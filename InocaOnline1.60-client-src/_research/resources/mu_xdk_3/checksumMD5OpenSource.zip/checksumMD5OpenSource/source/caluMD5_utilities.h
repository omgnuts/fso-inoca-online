#include <afx.h>

#ifndef _H_caluMD5_utilities
#define _H_caluMD5_utilities

void setFileHashingError(int error);
int getFileHashingError();

#endif