// This is not the real Types.r, which is a CodeWarrior-supplied Rez file
// that defines standard Mac resource types.

// This file exists here to suppress warnings in Visual C++ 5.0 caused by
// the fact that the cross-platform file dversion.r includes Types.r on Mac.
// The VC5 dependency checker doesn't understand #ifdefs, so it complains
// when it can't find Types.r.
